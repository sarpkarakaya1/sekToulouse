import React from 'react';

const LanguageSelector = () => {
  // Empty component - no language selector needed for English-only
  return null;
};

export default LanguageSelector;